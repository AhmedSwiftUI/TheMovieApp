//
//  MovieDetails.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import Foundation
import SwiftUI


// A struct that represents a show
struct Show: Identifiable {
    let id: Int
    let name: String
    let image: String
    let rating: Double
    let duration: Double
    let details: String
}




// A struct that represents a movie
struct Movie: Identifiable {
    let id: Int
    let name: String
    let image: String
    let rating: Double
    let duration: Double
    let details: String
}








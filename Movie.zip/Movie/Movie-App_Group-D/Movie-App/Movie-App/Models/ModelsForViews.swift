//
//  ModelsForViews.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation

//class ModelView : ObservableObject{
//
//    @Published var isOrderLoad = false
//    @Published var isRestaurantLoad = false
//    @Published var isRewardLoad = false
//
//    init() {
//
//        // load initial data
//        print("Home Data Loaded")
//    }
//    
//    func loadOrders(){
//
//        print("order Loaded")
//        isOrderLoad = true
//    }
//
//    func loadRestaurant(){
//
//        print("Restaurant Loaded")
//        isRestaurantLoad = true
//    }
//
//    func loadReward(){
//
//        print("reward Loaded")
//        isRewardLoad = true
//    }
//}

//
//  TicketsModel.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation

//struct Ticket: Identifiable {
//    let show: Show
//    var id = UUID()
////    var movieTitle: String
////    var theaterName: String
////    var showtime: String
//}

//
//  Imgs.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation
import SwiftUI
struct ImageIdentifiable: Identifiable {
    let id = UUID()
    let image: Image
}

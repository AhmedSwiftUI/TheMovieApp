//
//  TicketView.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

//import SwiftUI
//
//struct TicketsView: View {
//    @State var tickets: [Ticket] = []
//
//    var body: some View {
//        VStack {
//            if tickets.isEmpty {
//                Text("You currently have no tickets.")
//            } else {
//                List(selection: $tickets) { ticket in
//                    HStack {
//                        Text(ticket.movieTitle)
//                        Spacer()
//                        Text(ticket.showtime)
//                    }
//                }
//            }
//        }
//    }
//    func addTicket(ticket: Ticket){
//        tickets.append(ticket)
//    }
//}
//
//
//
//
//
//
//struct TicketView_Previews: PreviewProvider {
//    static var previews: some View {
//        TicketsView()
//    }
//}

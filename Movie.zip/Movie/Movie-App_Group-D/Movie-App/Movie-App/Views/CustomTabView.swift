//
//  CustomTabView.swift
//  Movie-App
//
//  Created by ahmed alharbi on 05/07/1444 AH.
//

import SwiftUI
struct CustomTabView: View {
    @AppStorage("shownOnBoarding") var shownOnBoarding: Bool = true
    @State var selectedTab = "Home"
    var tabs = ["Home","Search","Tickets", "Profile"]
    var nameTabs = ["Home","Search","Profile"]
    var myViews: [AnyView] = [AnyView(MainView()), AnyView(Text("Search")), AnyView(Tickets()),AnyView(Profile())]
    @State var selectedIndex = 0
    @Namespace var animation
    var body: some View {
        
        ZStack {
            VStack(spacing: 0) {
                GeometryReader { _ in
                    ZStack {
                        if selectedTab == "Home" {
                            myViews[0]
                        }else if selectedTab == "Search" {
                            myViews[1]
                        }else if selectedTab == "Tickets" {
                            myViews[2]
                        }else{
                            myViews[3]
                        }
                    }
                    
                }
                HStack(spacing: 0) {
                    ForEach(tabs, id: \.self) { tab in
                        TabButton(title: tab, tabNames: tab, selectedTab: $selectedTab, animation: animation)
                        
                        if tab != tabs.last {
                            Spacer(minLength: 0)
                        }
                    }
                }
                .padding(.horizontal, 30)
                .background(Color("blue1"))
            }
            .ignoresSafeArea(edges: .bottom)
            .background(Color.black.opacity(0.06).ignoresSafeArea(.all,edges: .all))
        }
        .fullScreenCover(isPresented: $shownOnBoarding) {
            OnboardingViews(showOnBoarding: $shownOnBoarding)
        }
        
        
        
    }
}

struct CustomTabView_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabView()
    }
}

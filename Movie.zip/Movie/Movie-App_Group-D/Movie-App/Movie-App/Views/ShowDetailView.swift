//
//  ShowDetailView.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import SwiftUI

// A view that shows the details of a selected show
struct ShowDetailView: View {
        let show: Show

    
    var body: some View {
        ZStack {
            Color("blue1")
                .ignoresSafeArea()
        ScrollView {
            
                
                VStack {
                    Image(show.image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 300, height: 450)
                        .cornerRadius(10)
                    
                    Text(show.name)
                        .font(.title)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 8)
                    
                    Text(show.details)
                        .font(.subheadline)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 4)
                        .textFieldStyle(.automatic)
                    Text("Rating: \(show.rating, specifier: "%.1f")/5.0")
                        .font(.subheadline)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 4)
                    ZStack {
                        
                        Button(action: {

                        }) {
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 160,height: 30)
                                .foregroundColor(.yellow)
                        }
                        Text("Book Now")
                    }
                    
                    Spacer()
                }
            }
        }
    }
}



//struct ShowDetailView_Previews: PreviewProvider {
//    static var previews: some View {
//        ShowDetailView(show: .init(id: 3, name: "ahmed", image: "img", rating: 4.1, duration: 2.20, details: "sdgwrg") )
//    }
//}

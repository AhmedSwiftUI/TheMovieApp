//
//  ContentView.swift
//  Movie-App
//
//  Created by Moha Bahusayn on 24/01/2023.
//

import SwiftUI

struct MainView: View {
    @State var shownOnBoarding: Bool = true
    @State private var selection = 0
    var body: some View {
        ZStack {
                NavigationStack {
                    
                    ScrollView {
                        PopularShowsOnboarding()
                        VStack(alignment: .leading) {
                            HStack {
                                Text("Showing Now")
                                    .bold()
                                    .font(.title)
                                    .foregroundColor(.cyan)
                                    .padding(.leading, 20)
                                
                                Spacer()
                            }.background(Color("blue1"))
                            Divider()
                            ScrollView(.horizontal) {
                                HStack(spacing: 20) {
                                    ForEach(shows) { show in
                                        NavigationLink(destination: ShowDetailView(show: show)) {
                                            ShowCard(show: show)
                                        }.background(Color("blue1"))
                                    }
                                }
                                .padding(.leading, 20)
                            }.background(Color("blue1"))
                            
                            HStack {
                                Text("Coming Soon")
                                    .bold()
                                    .font(.title)
                                    .foregroundColor(.cyan)
                                    .padding(.leading, 20)
                                   
                                
                                Spacer()
                            }.background(Color("blue1"))
                            
                            ScrollView(.horizontal) {
                                HStack(spacing: 20) {
                                    ForEach(movies) { movie in
                                        NavigationLink(destination: MovieDetailView(movie: movie)) {
                                            MovieCard(movie: movie)
                                        }.background(Color("blue1"))
                                    }
                                }
                                .padding(.leading, 20)
                            }
                        }
                        
                    }.background(Color("blue1"))
                    
//                    .navigationBarTitle("Top Movies")
//                    .toolbarColorScheme(.dark, for: .navigationBar)
                    
                    .background(Color("blue1"))
                    .toolbarBackground(Color("blue1"), for: .navigationBar)
                    
                }.background(Color("blue1"))
                

            }

    }

        
        
    }
    

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            MainView()
        }
    }


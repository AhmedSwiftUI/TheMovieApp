//
//  ShowCard.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import SwiftUI

// A view that represents a show card
struct ShowCard: View {
    let show: Show
    
    var body: some View {
        ZStack {
            Color("blue1")
                .ignoresSafeArea()
            VStack {
                Image(show.image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 140, height: 210)
                    .cornerRadius(10)
                
                Text(show.name)
                    .font(.headline)
                    .foregroundColor(Color("white1"))
                    .padding(.top, 8)
                
                Text("\(show.rating, specifier: "%.1f")/5.0")
                    .font(.subheadline)
                    .foregroundColor(Color("white1"))
                    .padding(.top, 4)
                HStack {
                    Image(systemName: "timer")
                        .font(.subheadline)
                        .foregroundColor(.white)
                        .padding(.top,4)
                    Text("\(show.duration, specifier:  "%.2f")")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    .padding(.top,4)
                }
                
            }
        }
    }
}

struct ShowCard_Previews: PreviewProvider {
    static var previews: some View {
        ShowCard(show: .init(id: 2, name: "ah", image: "aa", rating: 3.0, duration: 2.3, details: "dfbww"))
    }
}

//
//  MovieCard.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import SwiftUI

// A view that represents a movie card
struct MovieCard: View {
    let movie: Movie
    
    var body: some View {
        ZStack {
            Color("blue1")
                .ignoresSafeArea()
            VStack {
                Image(movie.image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 140, height: 210)
                    .cornerRadius(10)
                
                Text(movie.name)
                    .font(.headline)
                    .foregroundColor(Color("white1"))
                    .padding(.top, 8)
                
                Text("\(movie.rating, specifier: "%.1f")/5.0")
                    .font(.subheadline)
                    .foregroundColor(Color("white1"))
                    .padding(.top, 4)
                HStack {
                    Image(systemName: "timer")
                        .font(.subheadline)
                        .foregroundColor(.white)
                        .padding(.top,4)
                    Text("\(movie.duration, specifier:  "%.2f")")
                        .font(.subheadline)
                        .foregroundColor(.white)
                    .padding(.top,4)
                }
            }
        }
    }
}

struct MovieCard_Previews: PreviewProvider {
    static var previews: some View {
        MovieCard(movie: .init(id: 1, name: "1", image: "2", rating: 2, duration: 2.30, details: "dfdbdnd"))
    }
}

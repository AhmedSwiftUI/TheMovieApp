//
//  Tickets.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import SwiftUI

struct Tickets: View {
    var body: some View {
        
        ZStack {
            Color("blue1")
                .ignoresSafeArea()
            VStack {
                Text("Tickets")
                    .foregroundColor(Color("white1"))
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                Text("You currently have no tickets.")
                    .font(.body)
                    .foregroundColor(.gray)
                    .padding(.top, 10)
            }
        }
    }
}
struct Tickets_Previews: PreviewProvider {
    static var previews: some View {
        Tickets()
    }
}

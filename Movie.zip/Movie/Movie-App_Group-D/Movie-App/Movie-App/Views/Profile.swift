//
//  Profile.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import SwiftUI

struct Profile: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    
    var body: some View {
        ZStack {
            
            Color("blue1")
                .ignoresSafeArea()
            Toggle( isOn: $isDarkMode) {
                Text("نمط الواجهة")
                    .foregroundColor(Color("white1"))
                    .padding()
                
            }
            
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}

//
//  teview.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation
import SwiftUI

struct CustomTabView2: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @State var selectedTab = 0
    var tabs = ["Home","Search","Tickets", "Profile"]
    var nameTabs = ["Home","Search","Profile"]

    var body: some View {
        
        VStack(spacing: 0) {
           
            GeometryReader { _ in
                
                ZStack {
                    TabView(selection: $selectedTab) {
                        HomeView()
                            .tabItem {
                                Image("home")
                                Text("Home")
                            }
                            .tag(0)
                        SearchView()
                            .tabItem {
                                Image("search")
                                Text("Search")
                            }
                            .tag(1)
                        TicketsView()
                            .tabItem {
                                Image("tickets")
                                Text("Tickets")
                            }
                            .tag(2)
                        ProfileView()
                            .tabItem {
                                Image("profile")
                                Text("Profile")
                            }
                            .tag(3)
                    }
                }
                
            }
            
            // TabView ..
            HStack(spacing: 0) {
                ForEach(tabs, id: \.self) { tab in
                    
                    TabButton(title: tab, tabNames: tab, selectedTab: $selectedTab)
                        
                 
                    
                    if tab != tabs.last {
                        Spacer(minLength: 0)
                    }
                    
                }
                
            }
            
            .padding(.horizontal, 30)
            .background(Color("blue1"))
        }
        .ignoresSafeArea(edges: .bottom)
        .background(Color.black.opacity(0.06).ignoresSafeArea(.all,edges: .all))
    }
}

//
//  popular.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import SwiftUI

struct PopularShowsOnboarding: View {
    @State private var currentIndex = 0
    let timer = Timer.publish(every: 6, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color("blue1")
                .ignoresSafeArea()
            VStack {
                Text("Top Movies")
                    .foregroundColor(Color("white1"))
                    .font(.largeTitle)
                Image(shows[currentIndex].image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 250, height: 300)
                    .cornerRadius(10)
                Text(shows[currentIndex].name)
                    .font(.title)
                    .foregroundColor(Color("white1"))
                    .padding(.top, 8)
                    .onReceive(timer) { _ in
                        if currentIndex + 1 == shows.count {
                            currentIndex = 0
                        } else {
                            currentIndex += 1
                        }
                    }
            }.background(Color("blue1"))
        }
    }
    
    struct popular_Previews: PreviewProvider {
        static var previews: some View {
            PopularShowsOnboarding()
        }
    }
}

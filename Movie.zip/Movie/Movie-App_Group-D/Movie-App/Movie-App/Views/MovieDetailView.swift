//
//  MovieDetailView.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import SwiftUI

// A view that shows the details of a selected movie
struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        
            ZStack {
                Color("blue1")
                    .ignoresSafeArea()
                ScrollView {
                
                VStack {
                    Image(movie.image)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 300, height: 450)
                        .cornerRadius(10)
                    
                    Text(movie.name)
                        .font(.title)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 8)
                    Text(movie.details)
                        .font(.subheadline)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 4)
                        .textFieldStyle(.automatic)
                        .padding()
                    
                    Text("Rating: \(movie.rating, specifier: "%.1f")/5.0")
                        .font(.subheadline)
                        .foregroundColor(Color("white1"))
                        .padding(.top, 4)
                    ZStack {
                        
                        Button(action: {

                        }) {
                            RoundedRectangle(cornerRadius: 10)
                                .frame(width: 160,height: 30)
                                .foregroundColor(.yellow)
                        }
                        Text("Book Now")
                    }
                    
                    Spacer()
                }
            }
            }.background(Color("blue1"))
    }
}

struct MovieDetailView_Previews: PreviewProvider {
    static var previews: some View {
        MovieDetailView(movie: Movie.init(id: 2, name: "dg", image: "fbd", rating: 3.0, duration: 1.50, details: "dfhg"))
    }
}

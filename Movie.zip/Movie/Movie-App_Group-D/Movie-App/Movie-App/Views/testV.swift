//
//  testV.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import SwiftUI

struct CustomTabView2: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @State var selectedTab = 0
    @State var selectedTab1 = "Home"
    var tabs = ["Home","Search","Tickets", "Profile"]
    var nameTabs = ["Home","Search","Profile"]
    @Namespace var animation

    var body: some View {
        
        VStack(spacing: 0) {       
            GeometryReader { _ in
                
                ZStack {
                    MainView()
                }
                
            }
            
            // TabView ..
            HStack(spacing: 0) {
                ForEach(tabs, id: \.self) { tab in
                    
                    TabButton(title: tab, tabNames: tab, selectedTab: $selectedTab1, animation: animation )
                        
                 
                    
                    if tab != tabs.last {
                        Spacer(minLength: 0)
                    }
                    
                }
                
            }
            
            .padding(.horizontal, 30)
            .background(Color("blue1"))
        }
        .ignoresSafeArea(edges: .bottom)
        .background(Color.black.opacity(0.06).ignoresSafeArea(.all,edges: .all))
    }
}


struct testV_Previews: PreviewProvider {
    static var previews: some View {
        CustomTabView2()
    }
}

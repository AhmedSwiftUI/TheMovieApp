//
//  movies.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import Foundation


// An array of movie data that will be used in the main view
let movies: [Movie] = [
    Movie(id: 1, name: "The Shawshank Redemption", image: "shawshank", rating: 4.8, duration: 2.29, details: """
          The Shawshank Redemption is a 1994 American drama film directed by Frank Darabont and starring Tim Robbins and Morgan Freeman. The film is based on the 1982 novella "Rita Hayworth and Shawshank Redemption" by Stephen King. It tells the story of Andy Dufresne, a young man who is falsely convicted of murder and sent to the Shawshank prison. While in prison, he forms a friendship with a fellow inmate, Red, and together they find hope and redemption through acts of common decency. The film explores themes of hope, friendship, and the possibility of redemption. It was a commercial failure upon its release but later on, it received critical acclaim and it considered one of the greatest films ever made.
          """),
    Movie(id: 2, name: "The Godfather", image: "godfather", rating: 4.9, duration: 4.20, details: "Don Vito Corleone, head of a mafia family, decides to hand over his empire to his youngest son Michael. However, his decision unintentionally puts the lives of his loved ones in grave danger."),
    Movie(id: 3, name: "The Dark Knight", image: "dark", rating: 5.0, duration: 2.30, details: """
The Dark Knight is a 2008 superhero film directed by Christopher Nolan and starring Christian Bale as Batman, Heath Ledger as The Joker, Aaron Eckhart as Harvey Dent and Gary Oldman as Commissioner Gordon. It is the second installment in the Nolan's Batman film series. The story picks up where the first film left off, with Batman taking on a new and more dangerous threat in the form of the Joker, a chaotic and unpredictable criminal mastermind. As the Joker wreaks havoc on Gotham City, Batman, Gordon, and Dent team up to stop him, but Dent's descent into villainy as Two-Face adds another layer of complexity to the situation. The film is widely praised for Ledger's iconic portrayal of the Joker and it received critical acclaim and grossed over 1 billion dollars worldwide.
"""),
    Movie(id: 4, name: "Avatar", image: "avatar", rating: 5.0, duration: 2.30, details: """
          Avatar is a science fiction film about a disabled Marine veteran who is sent to infiltrate the indigenous population of a distant planet called Pandora in order to pave the way for a mining operation. He forms a bond with the Pandora's inhabitants, the Na'vi, and becomes torn between his duty and his new found loyalty. The film is known for its groundbreaking visual effects and its use of motion capture technology, it was directed by James Cameron and grossed over 2.8 billion dollars worldwide.
          """),
]

//
//  shows.swift
//  Movie-App
//
//  Created by ahmed alharbi on 03/07/1444 AH.
//

import Foundation


// An array of show data that will be used in the main view
let shows: [Show] = [
    Show(id: 1, name: "Alice Darling", image: "alice", rating: 4.5, duration: 1.30, details: "A young woman trapped in an abusive relationship becomes the unwitting participant in an intervention staged by her two closest friends."),
    Show(id: 2, name: "Avatar", image: "avatar", rating: 4.8, duration: 1.30, details: """
         Avatar is a science fiction film about a disabled Marine veteran who is sent to infiltrate the indigenous population of a distant planet called Pandora in order to pave the way for a mining operation. He forms a bond with the Pandora's inhabitants, the Na'vi, and becomes torn between his duty and his new found loyalty. The film is known for its groundbreaking visual effects and its use of motion capture technology, it was directed by James Cameron and grossed over 2.8 billion dollars worldwide.
         """),
    Show(id: 3, name: "Boss Baby", image: "boss", rating: 5.0, duration: 2.30, details: """
         The Boss Baby is a 2017 American computer-animated comedy film produced by DreamWorks Animation. The story is about a 7-year-old boy named Tim who is jealous of his new baby brother, who he believes is taking all of his parents' attention. But when Tim discovers that the baby is actually a secret agent from Baby Corp on a mission to prevent puppies from taking over the world, he becomes his unlikely partner in the battle for family supremacy. The film stars Alec Baldwin as the voice of the titular character, and it was directed by Tom McGrath. It was followed by a sequel named "The Boss Baby: Family Business" in 2021.
         """),
    Show(id: 4, name: "The comeback Trail", image: "comeback", rating: 5.0, duration: 2.30, details: "he Comeback Trail is a 2020 American crime comedy film directed by George Gallo and written by Gallo and Josh Posner, based on the 1982 film of the same name by Harry Hurwitz. It stars Robert De Niro, Tommy Lee Jones, Morgan Freeman, Zach Braff, Emile Hirsch, and Eddie Griffin."),
    Show(id: 5, name: "Concrete Cowboy", image: "concrete", rating: 5.0, duration: 2.30, details: """
         Concrete Cowboy" is a 2021 American drama film directed by Ricky Staub. The story follows a teenage boy named Cole, who is sent to live with his estranged father in North Philadelphia, where he discovers the city's vibrant urban cowboy subculture. The film stars Idris Elba as Cole's father and Caleb McLaughlin as Cole. The movie is based on the novel "Ghetto Cowboy" by Greg Neri and it is an exploration of the real-life Fletcher Street Stables community of North Philadelphia, and the relationships of Black cowboys and their horses. The film premiered at the Toronto International Film Festival in September 2021 and released on April 2, 2021 by Netflix.
         """),
    Show(id: 6, name: "Fall", image: "fall", rating: 5.0, duration: 2.30, details: """
The Fall" is a British-Irish crime drama television series. It was created, written, and directed by Allan Cubitt, and it features Gillian Anderson and Jamie Dornan as the lead characters. The show is set in Northern Ireland and it follows a senior police officer, DSI Stella Gibson, as she investigates a series of murders. Her prime suspect is a highly intelligent and charismatic serial killer, Paul Spector, who is a family man and a grief counselor by day. The series ran for five seasons, from 2013 to 2016. It received positive critical acclaim for its performances, direction, and storytelling.
"""),
    Show(id: 7, name: "Paws of fury", image: "fury", rating: 5.0, duration: 2.30, details: "Paws of Fury: The Legend of Hank is a 2022 computer-animated martial arts comedy film directed by Rob Minkoff, Mark Koetsier, and Chris Bailey (in Koetsier and Bailey's feature directorial debut). The film is a loose remake of the 1974 live-action film Blazing Saddles.[b][5] It features the voices of Michael Cera, Ricky Gervais, Mel Brooks, George Takei, Aasif Mandvi, Gabriel Iglesias, Djimon Hounsou, Michelle Yeoh, and Samuel L. Jackson. The film takes place in a world of anthropomorphic animals, in which a dog named Hank learns to become a samurai to save a cat village from a conniving landlord."),
    Show(id: 8, name: "Rons gone wrong", image: "rons", rating: 5.0, duration: 2.30, details: "dfhjiid digjdsphiejer oewjk wfkw posrkgpo pogwrpojwpiow p wogjwpoj srohkropwj ogjwpjwp hojeptohjeop rhj"),
    
]

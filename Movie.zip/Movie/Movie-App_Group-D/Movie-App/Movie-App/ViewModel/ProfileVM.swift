//
//  ProfileVM.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation

//class ProfileViewModel: ObservableObject {
//    @Published var language: String = ""
//
//    init() {
//        self.language = UserDefaults.standard.string(forKey: "language") ?? "English"
//    }
//
//    func updateLanguage(_ newLanguage: String) {
//        self.language = newLanguage
//        UserDefaults.standard.set(newLanguage, forKey: "language")
//    }
//}

//
//  Movie_AppApp.swift
//  Movie-App
//
//  Created by Moha Bahusayn on 24/01/2023.
//

import SwiftUI

@main
struct Movie_AppApp: App {
    @AppStorage("isDarkMode") private var isDarkMode = false

    init() {
//        UINavigationBar.appearance().backgroundColor = .orange
    }
    
    var body: some Scene {
        WindowGroup {
            CustomTabView()
                .preferredColorScheme(isDarkMode ? .dark : .light)
        }
    }
}

//
//  ButtonTab.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import Foundation
import SwiftUI

struct TabButton: View {
    var title: String
    var nameTabs = ["Home","Search","Profile"]
    var tabNames: String
    
    @Binding var selectedTab: String
    var animation: Namespace.ID
    var body: some View {
        Button {
            withAnimation{selectedTab = title}
        }
    label: {
        VStack(spacing: 6) {
            
            
            // انيميشن للشكل (يمين - يسار)
            ZStack {
                CustomShape()
                    .fill(Color.clear)
                    .frame(width: 45,height: 6)
                if selectedTab == title {
                    CustomShape()
                        .fill(Color.white)
                        .frame(width: 45,height: 6)
                        .matchedGeometryEffect(id: "Tab_Change", in: animation)
                }
                
            }
            .padding(.bottom, 10)
            Image( title)
                .renderingMode(.template)
                .resizable()
            // اذا كان التاب هو التايتل يعطي شفافية ٠.٩ واذا لا ٠.٢
                .foregroundColor(selectedTab == title ? Color.cyan : Color.black.opacity(0.2))
                .frame(width: 30, height: 30)
            
            Text(tabNames)
                .font(.caption)
                .fontWeight(.bold)
            // اذا كان التاب هو التايتل يعطي شفافية ٠.٩ واذا لا ٠.٢
                .foregroundColor(Color("white1").opacity(selectedTab == title ? 0.9 : 0.2))
                .padding(.vertical,7)
                .padding(.horizontal,7)
        }
    }
        
    }
}

//
//  OnBoardingView.swift
//  Movie-App
//
//  Created by ahmed alharbi on 06/07/1444 AH.
//

import SwiftUI

struct OnboardingViews: View {
    @Binding var showOnBoarding:Bool
    var body: some View {
        TabView {
            PageView(title: "Welcome to Movies App", messege: "Here you can watch the latest movies", imageName: "popcorn.fill", disMissButton: false, showOnBoarding:$showOnBoarding)
                .background(Color("blue1"))
                .ignoresSafeArea()
            PageView(title: "Best of Movies", messege: "Also you can find best rated movies", imageName: "play.rectangle.fill", disMissButton: true,showOnBoarding:$showOnBoarding)
                .background(Color.green)
        }.background(Color("blue1"))
            .tabViewStyle(PageTabViewStyle())
    }
    
    
    struct PageView: View {
        let title: String
        let messege: String
        let imageName: String
        let disMissButton: Bool
        @Binding var showOnBoarding:Bool
        var body: some View {
            ZStack {
                Color("blue1")
                    .ignoresSafeArea()
                VStack {
                    Image(systemName: imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200,height: 150)
                        .padding()
                        .foregroundColor(Color("white1"))
                    
                    Text(title)
                        .font(.system(size: 42))
                        .foregroundColor(Color("white1"))
                    Text(messege)
                        .font(.system(size: 24))
                        .multilineTextAlignment(.center)
                        .foregroundColor(Color("white1"))
                        .opacity(0.4)
                        .padding()
                    
                    if disMissButton {
                        Button {
                            showOnBoarding.toggle()
                        } label: {
                            Text("Go to the app")
                                .bold()
                                .foregroundColor(.black)
                                .frame(width: 200,height: 50)
                                .background(Color.yellow)
                                .cornerRadius(6)
                        }
                        
                    }
                }
            }
        }
    }
    
    
    
    
    
    //        struct OnboardingViews_Previews: PreviewProvider {
    //            static var previews: some View {
    //                OnboardingViews(showOnBoarding: sh)
    //            }
    //        }
    //    }
    
}
